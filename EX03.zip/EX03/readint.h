#pragma once
#ifndef READINT_H_

#define READINT_H_

#include <string>

int read_int(const std::string &prompt, int low, int high);

#endif