#include "readint.h"
#include<iostream>
#include <stdexcept>

using namespace std;

int read_int(const string &prompt, int low, int high)
{
	if (low >= high)
	{
		throw std::invalid_argument("invalid range");
	}
	if(low<=-2147483647||high>=2147483647)
	{
		{
			throw std::invalid_argument("invalid range");
		} 
	}
	
	int num;
	cout << prompt;
	cin >> num;
	if (num >= high || num <= low)
	{
		cout << "invalid value" << endl;
		throw 	std::invalid_argument("invalid range");
	}
	return num;
}
	

	
	
	
	/*
	int num = 0; 
	try
	{
		cout << prompt;
		cin >> num;
		if (num >= high || num <= low)
		{
			cout << "invalid value" << endl;
			throw 	std::invalid_argument("invalid range");
		}
		else
			return num;
	}
	catch (ios_base::failure& ex)
	{
		cout << "Bad numeric string -- try again\n";
		if (cin.eof())
		{
			throw std::ios_base::failure("Invalid input");
		}
		cin.clear();
		cin.ignore(numeric_limits<int>::max(), '\n');
	}*/
