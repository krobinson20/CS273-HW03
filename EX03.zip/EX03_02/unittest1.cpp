
#include "stdafx.h"
#include "CppUnitTest.h"
#include "readint.h"
#include<stdexcept>
#include<iostream>
#include<fstream>

using namespace Microsoft::VisualStudio::CppUnitTestFramework;
using namespace std;

namespace EX03_02
{		
	TEST_CLASS(UnitTest1)
	{
	public:
		
		TEST_METHOD(Expected0)
		{
			ifstream ss("..\\EX03\\zeroinput.txt");
			if (ss.fail())
				throw int(-1);
			streambuf *orig_cin = cin.rdbuf(ss.rdbuf());
			Assert::AreEqual(read_int("My Prompt: ", -3, -3),0);
			cin.rdbuf(orig_cin);
			ss.close();
		}
		TEST_METHOD(invalidargument)
		{
			auto func = []()
			{
				read_int("My Prompt: ", 5, 1);
			};
			Assert::ExpectException<std::invalid_argument>(func);
		}
		
		TEST_METHOD(negative_values)
		{
			ifstream ss("..\\EX03\\negativevalues.txt");
			if (ss.fail())
				throw int(-1);
			streambuf *orig_cin = cin.rdbuf(ss.rdbuf());
			Assert::AreEqual(read_int("My Prompt: ", 0, 4),0);
			cin.rdbuf(orig_cin);
			ss.close();
		}
		
		TEST_METHOD(invalidargument2)
		{
			auto func = []()
			{
				read_int("My Prompt: ", 0, 0);
			};
			Assert::ExpectException<std::invalid_argument>(func);
		}
		
	};
}